alert('Las reglas del juego son las siguientes: Deberás seleccionar las que piensas que son las respuestas correctas y enviar el cuestionario cuando estés segura de tus respuestas, ¡recuerda todo lo que leíste hasta ahora!');

let puntaje = 0;
let respuestas_correctas = {
    preg1: "op2", 
    preg2: "op3", 
    preg3: "op2", 
    preg4: "op2", 
    preg5: "op1", 
    preg6: "op1", 
    preg7: "op2", 
    preg8: "op3", 
    preg9: "op2", 
    preg10: "op2"
};

let reiniciar_juego = document.querySelector('#reiniciar-juego');
let ver_respuestas = document.querySelector('#verificar-respuestas');
let resultado = document.querySelector('#resultado');

function verificarRespuestas() {
    puntaje = 0; // Reinicia el puntaje a 0

    for (let i = 1; i <= 10; i++) {
        let respuesta = document.querySelector('input[name="preg' + i + '"]:checked');
        if (respuesta && respuesta.value === respuestas_correctas['preg' + i]) {
            puntaje++;
        }
    }

    alert('Respuestas correctas: ' + puntaje);
    resultado.innerText = 'Respuestas correctas: ' + puntaje; 
    reiniciar_juego.disabled= false;
}

// Reiniciar juego recargando la página
reiniciar_juego.addEventListener('click', function() {
    location.reload();
});

// Configura el evento click de verificar respuestas
ver_respuestas.addEventListener('click', verificarRespuestas);
