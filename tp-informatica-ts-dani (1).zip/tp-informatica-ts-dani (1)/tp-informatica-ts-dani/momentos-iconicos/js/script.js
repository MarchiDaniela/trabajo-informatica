let ingresar = confirm('¿Quieres jugar?');
let reiniciar = document.querySelector('#reiniciar-juego');
if (ingresar === true) {
    alert('Las reglas del juego son las siguientes: Deberas seleccionar las que piensas que son las respuestas correctas y enviar el cuestionario cuano estes segura de tus respuestas, recuerda odo lo que lesite hasta ahora!');
    agregarJugador();
}
contesta.addEventListener('click', () =>{
    clearTimeout(tiempoCuestionario);
    verificarRespuestas();
})

function agregarJugador() {
let nombre = prompt("Por favor, ingresa tu nombre");
let puntaje = 0;
let jugador = { nombre: nombre, puntaje: puntaje };
jugadores.push(jugador);

comenzar = confirm('¿Estás listo para comenzar ahora?');

if (comenzar) {
    iniciarTemporizador();
}
}
let respuestasCorrectas = {
    preg1: "op2", 
    preg2: "op3", 
    preg3: "op2", 
    preg4: "op2", 
    preg5: "op1", 
    preg6: "op1", 
    preg7: "op2", 
    preg8: "op3", 
    preg9: "op2", 
    preg10: "op2"
};

function verificarRespuestas() {
    let respuestasCorrectasContadas = 0; // Variable para contar las respuestas correctas

    for (let i = 1; i <= 10; i++) {
        let respuesta = document.querySelector(`input[name="preg${i}"]:checked`);
        if (respuesta && respuesta.value === respuestasCorrectas[`preg${i}`]) {
            variablePuntaje++;
            respuestasCorrectasContadas++; // Aumentar el conteo de respuestas correctas
        }
    }

    alert(`Tu puntaje es: ${variablePuntaje}`);
    
    // Guardar puntajes en localStorage
    if (jugadores.length > 0) {
        guardarPuntajes(jugadores[0].nombre, variablePuntaje, respuestasCorrectasContadas);
    }

    // Botón de reinicio del juego
    reiniciar.addEventListener('click', function() {
       location.reload();
      /* for(let i = 0; i < opciones.length; i ++){
        opciones[i].checked = false;
    }*/
    });
}

// Función para guardar puntajes en localStorage
function guardarPuntajes(nombre, puntaje1) {
    let puntuaciones = JSON.parse(localStorage.getItem('puntuaciones')) || [];
    puntuaciones.push({ nombre: nombre, puntaje: puntaje1});
    localStorage.setItem('puntuaciones', JSON.stringify(puntuaciones));
}
