// galeria de boosttrap, ejemplos en clase
(() => {
    'use strict';
  
    // Obtener todos los formularios a los que queremos aplicar estilos de validación personalizados de Bootstrap
    const forms = document.querySelectorAll('.needs-validation');
  
    // Bucle sobre los formularios y prevenir el envío
    Array.from(forms).forEach(form => {
      form.addEventListener('submit', event => {
        // Evitar envío si el formulario no es válido
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }
  
        // Añadir clase de validación
        form.classList.add('was-validated');
  
        // Seleccionar los campos del formulario
        const username = form.querySelector('[name="username"]');
        const emailAddress = form.querySelector('[name="email"]');
  
        // Validar campo de nombre de usuario
        if (username.value === "") {
          alert("Por favor, ingresa tu nombre de usuario.");
          username.focus();
          event.preventDefault();
          return false;
        }
  
        // Validar campo de correo electrónico
        if (emailAddress.value === "") {
          alert("Por favor, ingresa tu dirección de correo electrónico.");
          emailAddress.focus();
          event.preventDefault();
          return false;
        }
  
        // Validar formato de correo electrónico
        if (!emailIsValid(emailAddress.value)) {
          alert("Por favor, ingresa una dirección de correo electrónico válida.");
          emailAddress.focus();
          event.preventDefault();
          return false;
        }
  
        // Si todo está bien, se puede enviar el formulario
        return true;
      }, false);
          // Función para validar el formato del correo electrónico
    const emailIsValid = email => {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      };
    });
  
  
  })();

 
  